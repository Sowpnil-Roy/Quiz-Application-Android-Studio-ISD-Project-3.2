package com.psygon.tech.scholar.models

class Chapter(): BaseStudy() {
    var topicID: Int = -1
    var topicKey: String = ""
}