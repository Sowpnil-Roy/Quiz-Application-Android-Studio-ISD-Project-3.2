package com.psygon.tech.scholar.models

class ExamModel {
    var content: Content = Content()
    var givenAnswer: String = ""
    var isCorrect: Boolean = false
}