package com.psygon.tech.scholar.models

class HomeMenu {
    var name: String = ""
    var image: Int = 0
}