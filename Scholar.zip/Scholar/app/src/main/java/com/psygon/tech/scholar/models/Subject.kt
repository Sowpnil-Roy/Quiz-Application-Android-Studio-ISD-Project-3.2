package com.psygon.tech.scholar.models

class Subject(): BaseStudy() {

}