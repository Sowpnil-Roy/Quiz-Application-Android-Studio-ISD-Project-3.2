package com.psygon.tech.scholar.models

class Summary {
    var id: Int = -1
    var key: String = ""
    var correctCount: Int = 0
    var totalCount: Int = 0
    var name: String = ""
    var type: String = ""
}