package com.psygon.tech.scholar.models

class Test(): BaseStudy() {
    var contentList: MutableList<Content> = mutableListOf()
}