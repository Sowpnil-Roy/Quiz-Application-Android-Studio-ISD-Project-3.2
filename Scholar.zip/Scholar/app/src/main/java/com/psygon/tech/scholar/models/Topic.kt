package com.psygon.tech.scholar.models

class Topic(): BaseStudy() {
    var subjectID: Int = -1
    var subjectKey: String = ""
}