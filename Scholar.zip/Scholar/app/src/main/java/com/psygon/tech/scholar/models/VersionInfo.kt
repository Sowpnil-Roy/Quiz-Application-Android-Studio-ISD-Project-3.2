package com.psygon.tech.scholar.models

class VersionInfo {
    var versionNumber: Int = 0
}